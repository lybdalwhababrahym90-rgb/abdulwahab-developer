ABDULWAHAB DEVELOPER — PRO VERSION

Files:
- index.html: upgraded responsive bilingual portfolio (Arabic/English), modern styling, mobile navigation, project cards, scroll effects, WhatsApp contact button, GitHub links.
- profile.jpg: profile photo used by the page.

PUBLISH FROM YOUR PHONE:
1. Download and extract this ZIP.
2. Open your GitHub repository: lybdalwhababrahym90-rgb/abdulwahab-developer
3. Upload BOTH index.html and profile.jpg to the repository root (same level as the current index.html).
4. If GitHub asks whether to replace existing files, confirm the replacement.
5. Commit changes to the main branch.
6. Wait a minute or two, then refresh the GitHub Pages website.

Important:
- Keep the filename exactly profile.jpg and keep it beside index.html.
- This package does not itself configure GitHub OAuth or automatic commits to GitHub. Those require a secure backend and additional setup.
